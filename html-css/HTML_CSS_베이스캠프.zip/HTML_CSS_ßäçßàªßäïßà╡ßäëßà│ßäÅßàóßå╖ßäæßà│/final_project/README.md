# final_project

* 해당 강의는 'HTML/CSS 베이스캠프' 강의의 마지막 프로젝트입니다.
* 해당 프로젝트는 유튜브에도 공개되는 영상입니다.
* final 소스코드는 해당 강의에서만 제공됩니다. init 소스코드는 아래 GitHub 링크에서 받으실 수 있습니다.

* 냥이집사 호두 소개 홈페이지를 만듭니다.
* 실무와 가깝게 하기 위해 figma를 사용하여 디자인을 진행하였습니다.
* 해당 코드를 작성할 때 최대한 실무에 가깝게 진행을 합니다. 따라서 배우지 않은 내용이 나올 경우에는 충분히 설명드리도록 하겠습니다.
* +@로 더 다양한 경험을 해드리기 위해 일부러 선택한 기술도 있습니다.

* 디자인 링크: https://www.figma.com/file/s2PehJpnB0IUvl79k6tet1/HTML%2FCSS-베이스캠프?type=design&node-id=0%3A1&mode=design&t=g2kjYCFOoezZZ238-1
* 단축링크: https://weniv.link/fM4xh1

* GitHub 링크: https://github.com/weniv/html_css_basecamp